import sys
import os
sys.path.append(os.getcwd() + '/..')
from config import settings

print("Data folder found:", os.path.exists(settings.DATA_PATH))
